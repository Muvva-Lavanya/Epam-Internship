package com.epam.Decorator;
//basic ranking method for desktop and mobile version
interface Webpage {
	public int ranking();
}
